#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hacker Terminal Simulator
Имитация хакерской активности в терминале
"""

import time
import random
import sys
import os
from datetime import datetime

class HackerSimulator:
    def __init__(self):
        self.targets = [
            "TARGET: corporate-server-01",
            "TARGET: government-database",
            "TARGET: bank-network",
            "TARGET: military-systems",
            "TARGET: crypto-exchange",
            "TARGET: social-media-platform"
        ]
        
        self.ips = [
            "192.168.1.100", "10.0.0.50", "172.16.0.25",
            "203.45.67.89", "91.234.56.78", "45.123.89.12"
        ]
        
        self.ports = [22, 80, 443, 21, 25, 53, 110, 143, 993, 995, 3389, 5900]
        
        self.tools = [
            "nmap", "metasploit", "burp-suite", "wireshark", "john", 
            "hashcat", "aircrack-ng", "sqlmap", "nikto", "dirb"
        ]
        
        self.exploits = [
            "CVE-2021-44228", "CVE-2020-1472", "CVE-2019-0708",
            "CVE-2017-0144", "CVE-2016-5195", "CVE-2014-6271"
        ]
        
        self.passwords = [
            "admin", "password", "123456", "root", "toor",
            "administrator", "guest", "user", "test", "qwerty"
        ]

    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def print_colored(self, text, color_code="\033[92m"):
        print(f"{color_code}{text}\033[0m")

    def print_red(self, text):
        self.print_colored(text, "\033[91m")

    def print_green(self, text):
        self.print_colored(text, "\033[92m")

    def print_yellow(self, text):
        self.print_colored(text, "\033[93m")

    def print_blue(self, text):
        self.print_colored(text, "\033[94m")

    def print_magenta(self, text):
        self.print_colored(text, "\033[95m")

    def print_cyan(self, text):
        self.print_colored(text, "\033[96m")

    def typewriter_effect(self, text, delay=0.03):
        for char in text:
            print(char, end='', flush=True)
            time.sleep(delay)
        print()

    def random_delay(self, min_delay=0.5, max_delay=2.0):
        time.sleep(random.uniform(min_delay, max_delay))

    def show_banner(self):
        banner = """
╔══════════════════════════════════════════════════════════════╗
║                    🚀 HACKER SIMULATOR 🚀                    ║
║                                                              ║
║              Имитация хакерской активности                  ║
║                    (Только для развлечения)                  ║
╚══════════════════════════════════════════════════════════════╝
        """
        self.print_red(banner)
        self.random_delay(1, 2)

    def scan_network(self):
        self.print_cyan("🔍 [INFO] Начинаю сканирование сети...")
        self.random_delay(0.5, 1.0)
        
        for i in range(5):
            ip = random.choice(self.ips)
            port = random.choice(self.ports)
            status = random.choice(["OPEN", "CLOSED", "FILTERED"])
            
            if status == "OPEN":
                self.print_green(f"✅ {ip}:{port} - {status}")
            else:
                self.print_red(f"❌ {ip}:{port} - {status}")
            
            self.random_delay(0.2, 0.5)

    def brute_force_attack(self):
        self.print_yellow("🔓 [ATTACK] Запуск брутфорс атаки...")
        self.random_delay(0.5, 1.0)
        
        target = random.choice(self.targets)
        self.print_red(f"🎯 {target}")
        
        for i in range(10):
            password = random.choice(self.passwords)
            attempt = f"Попытка {i+1}: {password}"
            
            if i == 7:  # "Успешный" взлом
                self.print_green(f"✅ {attempt} - УСПЕХ!")
                self.print_green("🔓 Доступ получен!")
                break
            else:
                self.print_red(f"❌ {attempt} - ОШИБКА")
            
            self.random_delay(0.3, 0.8)

    def exploit_vulnerability(self):
        self.print_magenta("💥 [EXPLOIT] Поиск уязвимостей...")
        self.random_delay(0.5, 1.0)
        
        exploit = random.choice(self.exploits)
        self.print_yellow(f"🔍 Найдена уязвимость: {exploit}")
        self.random_delay(0.5, 1.0)
        
        self.print_red("💣 Запуск эксплойта...")
        for i in range(8):
            progress = "█" * (i + 1) + "░" * (8 - i - 1)
            self.print_cyan(f"[{progress}] {((i + 1) * 12.5):.1f}%")
            self.random_delay(0.2, 0.4)
        
        self.print_green("✅ Эксплойт выполнен успешно!")
        self.print_green("🎯 Система скомпрометирована!")

    def data_extraction(self):
        self.print_blue("📊 [DATA] Извлечение данных...")
        self.random_delay(0.5, 1.0)
        
        data_types = [
            "Пользовательские данные",
            "Финансовая информация", 
            "Конфиденциальные документы",
            "База данных клиентов",
            "Системные логи",
            "Криптографические ключи"
        ]
        
        for data_type in data_types:
            self.print_cyan(f"📁 Извлечение: {data_type}")
            self.random_delay(0.3, 0.7)
            
            # Имитация прогресса
            for i in range(5):
                dots = "." * (i + 1)
                print(f"   {dots}", end='\r')
                time.sleep(0.2)
            print()
            
            self.print_green(f"✅ {data_type} - извлечено успешно")

    def cover_tracks(self):
        self.print_yellow("🧹 [CLEANUP] Заметание следов...")
        self.random_delay(0.5, 1.0)
        
        actions = [
            "Удаление логов доступа",
            "Очистка временных файлов", 
            "Стирание следов в реестре",
            "Удаление истории команд",
            "Очистка кэша браузера"
        ]
        
        for action in actions:
            self.print_cyan(f"🧽 {action}...")
            self.random_delay(0.2, 0.5)
            self.print_green(f"✅ {action} - завершено")

    def show_final_stats(self):
        self.print_red("\n" + "="*60)
        self.print_red("📊 ИТОГОВАЯ СТАТИСТИКА АТАКИ")
        self.print_red("="*60)
        
        stats = {
            "Сканированных хостов": random.randint(50, 200),
            "Найденных уязвимостей": random.randint(3, 15),
            "Взломанных систем": random.randint(1, 5),
            "Извлечено записей": random.randint(1000, 50000),
            "Время атаки": f"{random.randint(15, 45)} минут"
        }
        
        for key, value in stats.items():
            self.print_cyan(f"{key}: {value}")
        
        self.print_green("\n🎉 Миссия выполнена успешно!")
        self.print_yellow("⚠️  Помните: это только симуляция!")

    def run_simulation(self):
        try:
            self.clear_screen()
            self.show_banner()
            
            # Основной цикл симуляции
            self.scan_network()
            self.random_delay(1, 2)
            
            self.brute_force_attack()
            self.random_delay(1, 2)
            
            self.exploit_vulnerability()
            self.random_delay(1, 2)
            
            self.data_extraction()
            self.random_delay(1, 2)
            
            self.cover_tracks()
            self.random_delay(1, 2)
            
            self.show_final_stats()
            
        except KeyboardInterrupt:
            self.print_red("\n\n🛑 Симуляция прервана пользователем")
            self.print_yellow("👋 До свидания!")

def main():
    print("🚀 Запуск Hacker Simulator...")
    time.sleep(1)
    
    simulator = HackerSimulator()
    simulator.run_simulation()

if __name__ == "__main__":
    main()
