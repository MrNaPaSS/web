# 🚀 ИНСТРУКЦИЯ ПО ЗАПУСКУ

## Быстрый запуск:
1. Запустите QUICK_START.bat
2. Или запустите START_PRODUCTION.bat для полного запуска

## Остановка:
- Запустите STOP_PRODUCTION.bat

## Проверка статуса:
- Запустите CHECK_STATUS.bat

## Подробная инструкция:
- Читайте PRODUCTION_DEPLOYMENT.md

## Важные файлы:
- authorized_users.json - пользователи
- signal_stats.json - статистика
- access_requests.json - запросы доступа

## Веб-приложение:
https://accessibility-gallery-column-olympus.trycloudflare.com
